
import React, { useState } from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";

export default function MusicLotto() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (name && phone && email) {
      console.log("Новая заявка:", { name, phone, email });
      setSubmitted(true);
    } else {
      alert("Пожалуйста, заполните все поля.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 p-6">
      <Card className="max-w-md w-full text-center">
        <CardContent>
          <h1 className="text-3xl font-bold mb-4">🎶 Запись на Музыкальное Лото</h1>
          {submitted ? (
            <div className="text-2xl text-green-200">Спасибо за регистрацию!</div>
          ) : (
            <div className="space-y-4">
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ваше имя"
              />
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Телефон"
              />
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
              />
              <Button onClick={handleSubmit} className="w-full text-lg">Записаться</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
